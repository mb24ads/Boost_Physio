package model;

public enum AppointmentStatus {

    AVAILABLE,
    BOOKED,
    CANCELLED,
    ATTENDED
}

